import json
from aws_invok import log_to_s3, send_to_queue
from validate import valid_email


def lambda_handler(event, context):
    try:
        print("we have started")
        # consuming event data providing its a list
        body = event
        
        invalid_subcribers = []
        valid_subscribers = []
        required_fields = ['Name', 'Email', 'opt-in', 'Topicid']
        
        # check if the parsed data is a list
        if not isinstance(body, list):
            log_to_s3(json.dumps(body))

        # Extract each items from the list and check if it has a value or it has the right format
        for item in body:
            if not isinstance(item, dict): # if item is an invalid dictionary, move it to invalid subscribers
                item['Error'] = "the item is not a valid dictionary for processing."
                invalid_subcribers.append(item)
                
            # check if there are more or less fields in each items and each fields are properly captured
            # cascaded if hep us get an exact comment as to why the user is tagged invalid
            if len(item) == 4 and all(field in item and item[field] for field in required_fields):
                    # check if email is properly formatted 
                    if valid_email(item['Email']):
                        if item['opt-in'] == 'yes': # we dont want to do anything if user did not opt in
                            # print("we have a valid Subscriber", item) uncommment this for Debugging
                            valid_subscribers.append(item) 
                    else:
                        item['Error'] = "Email is not Correct."
                        invalid_subcribers.append(item) #This means the email is not valid
            else:
                item['Error'] = "there are more or less keys in the field"
                invalid_subcribers.append(item)
        
        
        # print("Invalid Subscribers: ", invalid_subcribers) # uncommment this for debugging
        # print("Valid Subscribers list: ", valid_subscribers) #uncommment this for debuggin
        
                
        if invalid_subcribers:
            # print("we have invalid lists") # uncommment This for debugigng
            log_to_s3(invalid_subcribers)
            
        if valid_subscribers: #chat GPT, this section of the cofe is not working at all
            # print("we have valid subscribers") #uncomment this line for debugging
            send_to_queue(valid_subscribers)
        
        return {
            'statusCode': 200
        }
    
    # Handle errors here
    except ValueError as ve:
        # Handle errors related to data format or missing fields
        print("ValueError:", str(ve))
        return {
            'statusCode': 400,
            'body': json.dumps({'error': str(ve)})
        }
    except json.JSONDecodeError:
        # Handle JSON decoding issues
        print("JSONDecodeError: Failed to decode JSON")
        return {
            'statusCode': 400,
            'body': json.dumps({'error': 'Failed to decode JSON'})
        }
    except Exception as e:
        # Handle any other exceptions
        print("Exception:", str(e))
        return {
            'statusCode': 500,
            'body': json.dumps({'error': str(e)})
        }
