import re

# using regular expression to validate email entered
def valid_email(email):
    # Define a regular expression for a basic email validation
    email_regex = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
    
    # Use re.match to check if the email matches the pattern
    if re.match(email_regex, email):
        return True
    else:
        return False
