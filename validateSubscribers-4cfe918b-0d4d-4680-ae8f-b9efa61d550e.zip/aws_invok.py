import boto3
import uuid
import json
from datetime import datetime

# define aws api calls
s3_client = boto3.client('s3')
sqs_client = boto3.client('sqs')


# send invalid details to S3 Bucket for further processing
def log_to_s3(data):
    print("we called log to s3 buckeet")
    file_name = 'invalidEntry.log'
    # Generate a unique file name based on timestamp
    timestamp = datetime.utcnow().strftime('%Y-%m-%dT%H:%M:%S')
    unique_file_name = "invalidEntry"
    
    # Upload the data to S3
    s3_client.put_object(
        Bucket="oluwatobi-code-challenge",
        Key=unique_file_name,
        Body= f"Logged data to S3 {timestamp} {data}",
        ContentType='application/json'
    )
    print("we have completed log to s3bucket")

# send valid subscribers to SQS for further processing
def send_to_queue(valid_subscribers):
    print("we called sqs function")

    # URL of your SQS queue
    sqs_queue_url = 'https://sqs.us-east-1.amazonaws.com/237587954704/validSubscribersQueue'
        
    # Send the valid subscribers to the SQS queue
    response = sqs_client.send_message(
        QueueUrl=sqs_queue_url,
        MessageBody=json.dumps(valid_subscribers)
    )

    print("SQS SendMessage Response:", response)
