import json
import boto3
from botocore.exceptions import ClientError

# Initialize the DynamoDB client
dynamodb = boto3.resource('dynamodb')
table_name = 'SubscribersDB'
table = dynamodb.Table(table_name)

def lambda_handler(event, context):
    for record in event['Records']:
        # Parse the SQS message body
        body = json.loads(record['body'])
        
        # Process each entry in the body
        for item in body:
            email = item['Email']
            
            # Check if the entry exists in DynamoDB
            try:
                response = table.get_item(Key={'Email': email})
            # catch error while trying to fetch
            except ClientError as e:
                print(f"Error fetching data from DynamoDB: {e}")
                continue
            
            # If the item doesn't exist, insert it
            if 'Item' not in response:
                try:
                    table.put_item(Item=item)
                    print(f"Inserted item with email: {email}")
                except ClientError as e:
                    print(f"Error inserting data into DynamoDB: {e}")
            else:
                print(f"Duplicate found, skipping email: {email}")
                print(f"Existing item: {response['Item']}")
    
    return {
        'statusCode': 200,
        'body': json.dumps('Processing completed')
    }
